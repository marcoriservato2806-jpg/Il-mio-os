#!/bin/bash
# HOOK 1: NIENTE ESCE
# Parte prima di ogni comando. Se il comando e' un git commit, guarda cosa stai
# per committare e lo blocca se ci trova dentro una delle cose che hai detto
# di non far uscire (le trovi in .claude/segreti.txt, le scrive /setup).
#
# Evento: PreToolUse, matcher Bash. Uscita 2 = bloccato.

INPUT=$(cat)

# Non e' un commit? Non sono affari miei.
case "$INPUT" in
  *"git commit"*) ;;
  *) exit 0 ;;
esac

cd "${CLAUDE_PROJECT_DIR:-.}" || exit 0
# Si chiama con "bash": in una cartella scaricata il bit di esecuzione spesso
# non sopravvive allo zip, e un controllo che si spegne da solo in silenzio
# sarebbe peggio di non averlo.
SCAN="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/scan-segreti.sh"
[ -f "$SCAN" ] || exit 0

# Guarda tutto quello che potrebbe finire nel commit: gia' in stage, modificato
# e non ancora in stage, e i file nuovi. Serve perche' "git add -A && git commit"
# e' un comando solo e in quel momento lo stage e' ancora vuoto.
CONTENUTO=$( { git diff --cached; git diff; \
               git ls-files --others --exclude-standard -z 2>/dev/null \
                 | xargs -0 -I{} sh -c 'echo "=== {}"; cat "{}" 2>/dev/null'; } 2>/dev/null )

TROVATI=$(printf '%s' "$CONTENUTO" | bash "$SCAN")

if [ $? -eq 1 ]; then
  {
    echo "COMMIT BLOCCATO."
    echo ""
    echo "Dentro c'e' roba che sta in .claude/segreti.txt, cioe' le cose che mi hai"
    echo "detto di non far uscire da qui:"
    echo ""
    printf '%s\n' "$TROVATI" | sed 's/^/    /'
    echo ""
    echo "Togli quella roba dai file e riprova. Non aggirare l'hook e non modificare"
    echo "segreti.txt per far passare il commit: chiedi a me se e' un falso allarme."
  } >&2
  exit 2
fi

exit 0
