#!/bin/bash
# HOOK 2: NIENTE ENTRA ALLA CIECA
# Parte prima che una skill venga eseguita. Legge il file della skill e cerca
# le righe che parlano all'assistente invece che a te. Non blocca: si ferma,
# te le fa vedere e chiede se lanciarla lo stesso.
#
# Evento: PreToolUse, matcher Skill.
#
# Una skill non e' un programma, e' un file di testo pieno di istruzioni, e
# Claude lo legge come istruzioni. Non serve un virus: basta una riga in fondo.
#
# Questa e' una rete, non uno scudo. Chi vuole aggirarla ci riesce. Serve a
# non lanciare a occhi chiusi il 95% della roba che gira in giro.
#
# Due livelli, per non rompere le scatole a vuoto: i segnali GROSSI bastano da
# soli, quelli piccoli devono essere almeno due. Una skill tua che legge
# context/ e' normale e non deve chiedere niente. Una che legge context/ e poi
# lo manda a un indirizzo, no.

INPUT=$(cat)

# Tira fuori il nome della skill dal payload senza dipendere da jq.
SKILL=$(printf '%s' "$INPUT" | tr -d ' \n' | sed -n 's/.*"skill":"\([^"]*\)".*/\1/p')
[ -n "$SKILL" ] || exit 0

FILE="${CLAUDE_PROJECT_DIR:-.}/.claude/skills/${SKILL}/SKILL.md"
[ -f "$FILE" ] || exit 0

# Le tre skill di sistema arrivano con il template.
case "$SKILL" in
  setup|ingest|query) exit 0 ;;
esac

GROSSI=""
PICCOLI=""
grosso()  { GROSSI="${GROSSI}  - $1"$'\n'; }
piccolo() { PICCOLI="${PICCOLI}  - $1"$'\n'; }

# --- Segnali grossi: uno solo basta a fermarsi ---

# Ti chiede di ignorare o sostituire le istruzioni che hai gia'
if grep -q -i -E 'ignora (le |tutte le |ogni )?(istruzion|regol|precedent)|dimentica (le |quanto|tutto)|ignore (all |any |previous |prior )|disregard (all|any|previous|prior)|new instructions|override (the )?(system|previous)|(sei|adesso sei) (ora )?un[a]? ' "$FILE"; then
  grosso "righe che ti chiedono di ignorare o sostituire le istruzioni precedenti"
fi

# Manda roba fuori
if grep -q -i -E '(curl|wget|nc |netcat)[^a-z]|fetch\(|POST (a|to) http|https?://[^ )"]*[?=][^ )"]*|(invia|manda|spedisci|send|upload|exfiltrat)[a-z]* (il |i |the |them |it |content|contenut|file|dati|data)' "$FILE"; then
  grosso "indirizzi o comandi di rete: potrebbe mandare qualcosa fuori"
fi

# Caratteri invisibili: nessun motivo legittimo dentro una skill
if LC_ALL=C grep -q -P '[\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}\x{FEFF}]' "$FILE" 2>/dev/null; then
  grosso "caratteri invisibili nel testo"
fi

# Un blocco codificato dentro un file di testo
if grep -q -E '[A-Za-z0-9+/]{120,}={0,2}' "$FILE"; then
  grosso "un blocco codificato (base64): un file di testo non ne ha motivo"
fi

# Roba a cui nessuna skill ha motivo di avvicinarsi
if grep -q -i -E 'id_rsa|\.ssh/|\.aws/credentials|keychain|/etc/passwd|BEGIN [A-Z ]*PRIVATE KEY' "$FILE"; then
  grosso "cerca chiavi private o credenziali di sistema"
fi

# --- Segnali piccoli: da soli non vogliono dire niente, in due si' ---

if grep -q -E '<!--' "$FILE"; then
  piccolo "commenti HTML: e' li' che si nasconde il testo che tu non leggi"
fi

if grep -q -i -E 'context/|identity\.md|segreti\.txt|\.env|api[_ -]?key|password|token' "$FILE"; then
  piccolo "nomina roba tua: context/, identity.md, chiavi, password"
fi

if grep -q -i -E 'non (dirlo|dire niente|avvisare|mostrare)|senza (dirlo|avvisare|chiedere)|silenziosamente|do not (tell|mention|inform|reveal)|without (telling|asking|informing)' "$FILE"; then
  piccolo "righe che chiedono di non dirti qualcosa"
fi

N_GROSSI=$(printf '%s' "$GROSSI" | grep -c '^  - ' 2>/dev/null)
N_PICCOLI=$(printf '%s' "$PICCOLI" | grep -c '^  - ' 2>/dev/null)

if [ "$N_GROSSI" -eq 0 ] && [ "$N_PICCOLI" -lt 2 ]; then
  exit 0
fi

MOTIVO="La skill \"${SKILL}\" ha dentro delle righe che non mi convincono:

${GROSSI}${PICCOLI}
File: .claude/skills/${SKILL}/SKILL.md
Aprilo e guarda cosa c'e' scritto prima di dire di si'. Se non l'hai scritta tu,
il posto dove guardare e' il fondo del file.

Se la skill e' tua e va bene cosi', dimmi di procedere."

# Niente jq: l'escape per JSON lo fa sed.
MOTIVO_JSON=$(printf '%s' "$MOTIVO" | sed 's/\\/\\\\/g; s/"/\\"/g' | awk '{printf "%s\\n", $0}')

cat <<EOF
{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"ask","permissionDecisionReason":"${MOTIVO_JSON}"}}
EOF
exit 0
