#!/bin/bash
# Cerca nel testo che gli passi i pattern elencati in .claude/segreti.txt
# Uso:   qualcosa | scan-segreti.sh
# Esce 1 e stampa le righe trovate se becca qualcosa, 0 se e' pulito.
# Lo usano due hook: "niente esce" e "niente si perde".

PATTERNS="${CLAUDE_PROJECT_DIR:-.}/.claude/segreti.txt"

# Nessuna lista, niente da cercare. Non e' un errore: e' un sistema appena scaricato.
[ -f "$PATTERNS" ] || exit 0

# Toglie righe vuote e commenti. Se non resta niente, non c'e' niente da cercare.
ATTIVI=$(grep -v '^[[:space:]]*#' "$PATTERNS" | grep -v '^[[:space:]]*$')
[ -n "$ATTIVI" ] || exit 0

TROVATI=$(grep -n -i -E -f <(printf '%s\n' "$ATTIVI") 2>/dev/null | head -20)

if [ -n "$TROVATI" ]; then
  printf '%s\n' "$TROVATI"
  exit 1
fi
exit 0
