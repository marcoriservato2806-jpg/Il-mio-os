#!/bin/bash
# HOOK 3: NIENTE SI PERDE
# Parte dopo ogni modifica a un file e fa un commit automatico. Serve a una cosa
# sola: quando ti rompe qualcosa, torni indietro di un commit e sei a posto.
#
# Evento: PostToolUse, matcher Edit|Write.
#
# Fa la stessa verifica dell'hook 1 prima di committare. Senza, il commit
# automatico sarebbe la porta di servizio che aggira il controllo sui segreti.

cd "${CLAUDE_PROJECT_DIR:-.}" || exit 0

git rev-parse --git-dir >/dev/null 2>&1 || exit 0
git diff --quiet && git diff --cached --quiet && \
  [ -z "$(git ls-files --others --exclude-standard)" ] && exit 0

SCAN="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/scan-segreti.sh"
if [ -f "$SCAN" ]; then
  CONTENUTO=$( { git diff; git diff --cached; \
                 git ls-files --others --exclude-standard -z 2>/dev/null \
                   | xargs -0 -I{} sh -c 'cat "{}" 2>/dev/null'; } 2>/dev/null )
  if ! printf '%s' "$CONTENUTO" | bash "$SCAN" >/dev/null; then
    echo "Non ho fatto il commit automatico: nei file modificati c'e' qualcosa che sta in .claude/segreti.txt. Le modifiche sono ancora li', nessuna e' persa." >&2
    exit 0
  fi
fi

git add -A >/dev/null 2>&1
git commit -q -m "auto: $(date '+%Y-%m-%d %H:%M')" >/dev/null 2>&1

exit 0
