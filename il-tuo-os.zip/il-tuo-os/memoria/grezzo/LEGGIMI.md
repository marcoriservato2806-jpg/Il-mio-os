Ci butti dentro roba: PDF, trascrizioni di call, articoli, export, appunti. In qualsiasi formato, senza rinominare niente e senza ordinare niente.

**Claude non modifica mai i file di questa cartella.** Li legge, e quello che capisce lo scrive in `memoria/wiki/`. Il grezzo resta com'era per sempre, così quando fra sei mesi una pagina della wiki ti sembra sbagliata puoi tornare alla fonte e controllare. Se la fonte fosse stata riscritta, non ci sarebbe più niente a cui tornare.

Quando hai messo qualcosa qui dentro, lancia `/ingest`.

Questo file puoi cancellarlo appena la cartella ha dentro qualcosa di tuo.
